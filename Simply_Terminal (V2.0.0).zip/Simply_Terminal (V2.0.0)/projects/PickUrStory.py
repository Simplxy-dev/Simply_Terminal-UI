import sys
import time

# Helper function to print text slowly
def slow_print(text, delay=0.02):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()  # Make sure the text is printed immediately
        time.sleep(delay)   # Wait before printing the next character
    print()  # Move to a new line after the text is printed

# Defining start of game function
def start():
    slow_print("\nYou are an adventurer exploring an ancient temple in search of a legendary treasure. The temple is full of traps, puzzles, and decisions. Your goal is to find the treasure and escape safely.")
    slow_print("You enter a temple and see two corridors.")
    slow_print("Which do you want to take?")
    slow_print("1. Corridor on the left")
    slow_print("2. Corridor on the right")
    
    choice = input("Which corridor do you choose (1, 2): ")

    if choice == "1":
        left_corridor()
    elif choice == "2":
        right_corridor()
    else:
        slow_print("Invalid choice! Please enter '1' or '2'.")
        start()  # Restart if the input is invalid

# Function for the left corridor (puzzle)
def left_corridor():
    slow_print("You follow the left corridor.")
    slow_print("The walls are covered in ancient symbols. You spot a pedestal with a scroll on it...")
    slow_print("Do you want to open it or go back?")
    choice = input("y/n: ")

    if choice == "y":
        slow_print("The scroll reads as follows:")
        slow_print("I speak without a mouth and hear without ears. I have no body, but I come alive with wind.")
        answer = input("What am I (one word): ").strip().lower()  # Convert to lowercase for easier comparison

        if answer == "echo":
            slow_print("Correct! The wall in front of you lifts up to reveal a grand room filled with treasure!")
            treasure_room()
        else:
            slow_print("That is not correct. The scroll crumbles into dust and a hidden trapdoor opens beneath you!")
            slow_print("You fall into a pit of spikes... Game Over!")
    elif choice == "n":
        slow_print("You return to where you began.")
        slow_print("Would you like to go to the other corridor?")
        choice = input("yes/no: ").strip().lower()

        if choice == "yes":
            right_corridor()
        else:
            slow_print("You stay at the starting point. The temple remains silent.")
    else:
        slow_print("Invalid choice! Please enter 'y' or 'n'.")
        left_corridor()  # Restart if the input is invalid

# Function for the right corridor (bear encounter and more)
def right_corridor():
    slow_print("You walk down the corridor on the right.")
    slow_print("The air becomes thick with dust. The corridor curves, and you begin to hear low growls.")
    slow_print("Suddenly, a large bear leaps out from behind a pillar!")
    slow_print("What will you do?")
    slow_print("1. Fight the bear")
    slow_print("2. Run away")
    
    choice = input("Your choice (1 or 2): ")

    if choice == "1":
        slow_print("You bravely decide to fight the bear.")
        slow_print("The bear roars and charges at you. You fight valiantly, but eventually the bear overwhelms you. Game Over!")
    elif choice == "2":
        slow_print("You quickly turn and run down the corridor.")
        slow_print("You barely escape the bear, but you've found a door that leads to a treasure room!")
        treasure_room()
    else:
        slow_print("Invalid choice! Please enter '1' or '2'.")
        right_corridor()  # Restart the fight/escape choices if invalid

# Function for the treasure room
def treasure_room():
    slow_print("You enter the treasure room and are dazzled by the sight of piles of gold, jewels, and ancient artifacts!")
    slow_print("You walk deeper into the room and see three chests. Which one will you open?")
    slow_print("1. The golden chest")
    slow_print("2. The wooden chest with intricate carvings")
    slow_print("3. The small, iron-bound chest")

    choice = input("Choose a chest (1, 2, or 3): ")

    if choice == "1":
        slow_print("You open the golden chest and find a beautiful, shining amulet. As you hold it, a soft voice whispers in your mind...")
        slow_print("'The amulet is cursed. You shall never escape the temple.'")
        slow_print("The walls begin to close in, and you are trapped forever. Game Over!")
    elif choice == "2":
        slow_print("You open the wooden chest and find a scroll. It reads:")
        slow_print("'The way forward is not always through the front door. Find the hidden path and escape.'")
        slow_print("You decide to follow the advice and find a hidden passage behind the chest.")
        slow_print("You escape the temple with the treasure, but the adventure is far from over...")
        slow_print("Congratulations, you found the secret escape!")
    elif choice == "3":
        slow_print("You open the small, iron-bound chest and find a map of the temple.")
        slow_print("Following the map, you discover a secret exit in the back of the temple. You escape with treasure and knowledge!")
        slow_print("Congratulations, you survived the temple's many dangers!")
    else:
        slow_print("Invalid choice! Please enter '1', '2', or '3'.")
        treasure_room()  # Restart if the input is invalid

# Start the game
start()
