import random

def guessDice():
    print("Guess a number between 1-6")
    return int(input("Input: "))  # Return the choice

def restartselect():
    restartchoose = input("Would you like to start? (y/n): ").strip().lower()
    
    if restartchoose == "y":
        print("You've selected to start the game")
        print("In this game, your objective is to guess what # the dice will land on (1-6)")
        guessDice()
        if choice <= 6:
            print(f"[You guessed: {choice}]")
        else:
            print("Invalid Selection")
            choice = guessDice()  # Re-ask for input

        rollDice(choice)
    
    elif restartchoose == "n":
        quit()
    else:
        print("Incorrect selection!")
        restartselect()

def rollDice(choice):
    diceNumber = random.randint(1, 6)
    print(f"[The dice rolled: {diceNumber}]")
    restartselect()

print("Welcome to Roll the Dice")
restartselect()
