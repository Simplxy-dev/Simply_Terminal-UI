import time 

# Variables
introCountdown = 5

# FUNCTIONS:
def start():
# Text on start
    introCountdown = 5
    print("Welcome to a text-based StoryRPG!")
    time.sleep(1)
    print("The game begins in...")
    while introCountdown > 0:
        time.sleep(1)
        print(f"[{introCountdown}]")
        introCountdown -= 1 
    print("You wake up in the middle of a big white room the doors are locked...")
    time.sleep(1)

def beginning():
    print("What would you like to do?")
    time.sleep(1)
    print("1. Investigate the room")
    time.sleep(1)
    print("2. Try opening the doors")
    time.sleep(1)
    choice = input("Select which action would you like to do: ")
    if choice == "1":
        roomInvestigate()
    elif choice =="2":
        openDoor()


def openDoor():
    time.sleep(1)
    print("You attempt to open the big door... \nIt doesnt budge..")
    beginning()


def roomInvestigate ():
    print("You Investigate the room and look for anything odd...")
    time.sleep(1)
    print("You find a little piece of white paper lodged within the wall's tiles")
    time.sleep(1)
    print("It reads as follows...")
    time.sleep(1)
    print("I can only live where there is light, but I die if the light shines on me.")
    answer = input("What am I?: ").strip().lower()
    if answer == "shadow":
        time.sleep(1)
        print('As you say "shadow" you hear gears turned and the metal door creaks open...')

start()