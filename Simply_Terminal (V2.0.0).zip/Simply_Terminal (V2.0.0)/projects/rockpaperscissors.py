import random

# Possible moves
moves = ['rock', 'paper', 'scissors']

# Function to determine the winner
def determine_winner(player_move, bot_move):
    if player_move == bot_move:
        return "It's a tie!"
    elif (player_move == 'rock' and bot_move == 'scissors') or \
         (player_move == 'paper' and bot_move == 'rock') or \
         (player_move == 'scissors' and bot_move == 'paper'):
        return "You win!"
    else:
        return "Bot wins!"

# Function to predict bot's next move with randomness
def predict_bot_move(player_history):
    if len(player_history) == 0:
        return random.choice(moves)  # Random move if no history
    
    # Basic strategy with randomness
    last_move = player_history[-1]
    bot_choice = random.random()

    # 70% of the time, the bot tries to counter the last move
    if bot_choice < 0.7:
        if last_move == 'rock':
            return 'paper'  # Paper beats rock
        elif last_move == 'paper':
            return 'scissors'  # Scissors beats paper
        else:
            return 'rock'  # Rock beats scissors
    else:
        # 30% of the time, the bot picks randomly
        return random.choice(moves)

# Play the game
def play_game():
    print("Welcome to Rock, Paper, Scissors!")
    
    # Store the player's previous moves
    player_history = []
    
    while True:
        # Get the player's move
        player_move = input("Enter your move (rock/paper/scissors): ").lower()
        
        if player_move not in moves:
            print("Invalid move! Please enter rock, paper, or scissors.")
            continue
        
        # Add the move to history
        player_history.append(player_move)
        
        # Bot makes a move based on the player's history
        bot_move = predict_bot_move(player_history)
        print(f"Bot's move: {bot_move}")
        
        # Determine the winner
        result = determine_winner(player_move, bot_move)
        print(result)
        
        # Ask if the player wants to play again
        play_again = input("Do you want to play again? (y/n): ").lower()
        if play_again != 'y':
            print("Goodbye!")
            break

# Start the game
play_game()
