import tkinter as tk
import signal
import sys

def create_window():
    def duplicate_windows():
        # Duplicate the current number of windows
        current_windows = len(windows)
        for _ in range(current_windows):
            create_window()
        # Close the current window
        new_window.destroy()

    # Create a new window
    new_window = tk.Tk()
    new_window.title("N0 ESC4P3")
    new_window.geometry("300x150")
    
    # Add the message to the window
    message_label = tk.Label(new_window, text='"Welcome houdert" - You cannot escape >:D', wraplength=280, justify="center")
    message_label.pack(pady=20)
    
    # Override the close button (X) behavior
    new_window.protocol("WM_DELETE_WINDOW", duplicate_windows)
    
    # Create a "Close" button that duplicates windows
    close_button = tk.Button(new_window, text="ESC4P3", command=duplicate_windows)
    close_button.pack(pady=10)

    # Bind the backslash key to close all windows
    new_window.bind(r"<.>", close_all_windows)
    
    # Add the new window to the list of windows
    windows.append(new_window)

def close_all_windows(event=None):
    """Close all windows and exit the script."""
    for window in windows:
        try:
            window.destroy()  # Destroy each window
        except:
            pass
    sys.exit(0)  # Exit the script

def handle_exit_signal(signum, frame):
    """Handle Ctrl+C signal to gracefully exit."""
    print("\nExiting...")
    close_all_windows()

# Register the SIGINT (Ctrl+C) handler
signal.signal(signal.SIGINT, handle_exit_signal)

# List to keep track of all windows
windows = []

# Create the first window
create_window()

# Start the Tkinter event loop
tk.mainloop()

