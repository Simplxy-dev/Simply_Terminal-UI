import subprocess

def scan_bluetooth_windows():
    print("Scanning for Bluetooth connections...")
    try:
        # Use PowerShell to list paired or visible devices
        result = subprocess.run(
            ["powershell", "-Command", "Get-PnpDevice -Class Bluetooth"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            print("Connections found:")
            print(result.stdout)
        else:
            print("No connections found or an error occurred.")
            print(result.stderr)
    except Exception as e:
        print(f"Error during scan: {e}")

if __name__ == "__main__":
    scan_bluetooth_windows()
