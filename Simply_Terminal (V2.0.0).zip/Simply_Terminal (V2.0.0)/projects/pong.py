import turtle
import random

# Screen setup
win = turtle.Screen()
win.title("Pong: Player vs CPU")
win.bgcolor("black")
win.setup(width=800, height=600)
win.tracer(0)

# Paddle 1 (Player)
player_paddle = turtle.Turtle()
player_paddle.speed(0)
player_paddle.shape("square")
player_paddle.color("white")
player_paddle.shapesize(stretch_wid=6, stretch_len=1)
player_paddle.penup()
player_paddle.goto(-350, 0)

# Paddle 2 (CPU)
cpu_paddle = turtle.Turtle()
cpu_paddle.speed(0)
cpu_paddle.shape("square")
cpu_paddle.color("white")
cpu_paddle.shapesize(stretch_wid=6, stretch_len=1)
cpu_paddle.penup()
cpu_paddle.goto(350, 0)

# Ball
ball = turtle.Turtle()
ball.speed(40)
ball.shape("circle")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 0.25  # Ball's x direction
ball.dy = 0.25  # Ball's y direction

# Score
player_score = 0
cpu_score = 0

# Pen for displaying score
score_display = turtle.Turtle()
score_display.speed(0)
score_display.color("white")
score_display.penup()
score_display.hideturtle()
score_display.goto(0, 260)
score_display.write("Player: 0  CPU: 0", align="center", font=("Courier", 24, "normal"))

# Movement variables
player_speed = 0

# Functions for smooth movement
def move_up():
    global player_speed
    player_speed = 0.5  # Set positive speed for upward movement

def move_down():
    global player_speed
    player_speed = -0.5  # Set negative speed for downward movement

def stop():
    global player_speed
    player_speed = 0  # Stop paddle movement

# Keyboard bindings
win.listen()
win.onkeypress(move_up, "w")
win.onkeypress(move_down, "s")
win.onkeyrelease(stop, "w")
win.onkeyrelease(stop, "s")

# Main game loop
while True:
    win.update()

    # Move the player paddle smoothly
    player_paddle.sety(player_paddle.ycor() + player_speed)

    # Bound the player paddle within the screen
    if player_paddle.ycor() > 250:
        player_paddle.sety(250)
    elif player_paddle.ycor() < -250:
        player_paddle.sety(-250)

    # Move the ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Ball collision with top/bottom walls
    if ball.ycor() > 290:
        ball.sety(290)
        ball.dy *= -1

    if ball.ycor() < -290:
        ball.sety(-290)
        ball.dy *= -1

    # Ball collision with paddles
    if (ball.xcor() > 340 and ball.xcor() < 350) and (ball.ycor() < cpu_paddle.ycor() + 50 and ball.ycor() > cpu_paddle.ycor() - 50):
        ball.setx(340)
        ball.dx *= -1

    if (ball.xcor() < -340 and ball.xcor() > -350) and (ball.ycor() < player_paddle.ycor() + 50 and ball.ycor() > player_paddle.ycor() - 50):
        ball.setx(-340)
        ball.dx *= -1

    # Ball out of bounds
    if ball.xcor() > 390:
        ball.goto(0, 0)
        ball.dx *= -1
        player_score += 1
        score_display.clear()
        score_display.write(f"Player: {player_score}  CPU: {cpu_score}", align="center", font=("Courier", 24, "normal"))

    if ball.xcor() < -390:
        ball.goto(0, 0)
        ball.dx *= -1
        cpu_score += 1
        score_display.clear()
        score_display.write(f"Player: {player_score}  CPU: {cpu_score}", align="center", font=("Courier", 24, "normal"))

    # CPU paddle movement
    if cpu_paddle.ycor() < ball.ycor() and abs(cpu_paddle.ycor() - ball.ycor()) > 10:
        cpu_paddle.sety(cpu_paddle.ycor() + 2)

    if cpu_paddle.ycor() > ball.ycor() and abs(cpu_paddle.ycor() - ball.ycor()) > 10:
        cpu_paddle.sety(cpu_paddle.ycor() - 2)
