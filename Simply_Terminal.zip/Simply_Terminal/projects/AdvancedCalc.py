import tkinter as tk
from tkinter import messagebox
import math

# Function to handle button clicks
def button_click(operation):
    global entry
    try:
        current = entry.get()
        if operation == "C":
            entry.delete(0, tk.END)  # Clear input
        elif operation == "=":
            result = eval(current)  # Evaluate expression
            entry.delete(0, tk.END)
            entry.insert(0, str(result))
        elif operation == "√":
            number = float(current)
            if number < 0:
                messagebox.showerror("Error", "Cannot calculate square root of a negative number!")
            else:
                result = math.sqrt(number)
                entry.delete(0, tk.END)
                entry.insert(0, str(result))
        else:
            entry.insert(tk.END, operation)  # Append operation or number
    except Exception as e:
        messagebox.showerror("Error", f"Invalid input or operation!\n{e}")

# Create the main window
window = tk.Tk()
window.title("Advanced Calculator")
window.geometry("400x500")
window.resizable(False, False)
window.configure(bg="#2C2C34")

# Create an Entry widget for input/output
entry = tk.Entry(window, width=18, font=("Helvetica", 24), bd=2, relief="solid", justify="right", bg="#1C1C22", fg="#FFFFFF")
entry.grid(row=0, column=0, columnspan=4, padx=10, pady=20, ipady=10)

# Define button labels and their styles
buttons = [
    ("7", "#383845"), ("8", "#383845"), ("9", "#383845"), ("/", "#EB9F29"),
    ("4", "#383845"), ("5", "#383845"), ("6", "#383845"), ("*", "#EB9F29"),
    ("1", "#383845"), ("2", "#383845"), ("3", "#383845"), ("-", "#EB9F29"),
    ("0", "#383845"), (".", "#383845"), ("√", "#EB9F29"), ("+", "#EB9F29"),
    ("C", "#D32F2F"), ("=", "#2196F3")
]

# Add buttons to the GUI
row, col = 1, 0
for label, color in buttons:
    tk.Button(
        window, text=label, width=5, height=2, font=("Helvetica", 18), 
        bg=color, fg="#FFFFFF", bd=0, highlightthickness=0,
        command=lambda b=label: button_click(b)
    ).grid(row=row, column=col, padx=5, pady=5, sticky="nsew")
    col += 1
    if col > 3:
        col = 0
        row += 1

# Adjust row and column weights for responsiveness
for i in range(6):
    window.rowconfigure(i, weight=1)
for j in range(4):
    window.columnconfigure(j, weight=1)

# Run the application
window.mainloop()
