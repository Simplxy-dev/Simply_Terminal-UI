import colorama
import time
import sys
import psutil
import webbrowser
import pyfiglet
import os
import threading
import subprocess
import platform
import shutil
import socket
import whois as pywhois  

print(">>> simply_ui.py loaded!")
import requests

NEWS_API_KEY = "bd206ed387934aee8c34785e87877625"

def cmd_news():
    url = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={NEWS_API_KEY}"
    try:
        resp = requests.get(url)
        data = resp.json()
        if data["status"] != "ok":
            print("[!] Failed to fetch news")
            return
        articles = data.get("articles", [])[:5]
        print("\nTop 5 News Headlines:\n")
        for i, art in enumerate(articles, 1):
            print(f"{i}. {art['title']}")
            print(f"   Source: {art['source']['name']}")
            print(f"   URL: {art['url']}\n")
    except Exception as e:
        print(f"[!] Error fetching news: {e}")

COMMON_PORTS = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    139: "NetBIOS",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    3306: "MySQL",
    3389: "RDP"
}
open_ports = []

def scan_port(host, port, timeout=1):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.5)
    try:
        s.connect((host, port))
        try:
            s.send(b"Hello\r\n")
            banner = s.recv(1024).decode().strip()
        except:
            banner = "No Banner"
        print(f"[+] Port {port} OPEN - {COMMON_PORTS.get(port, 'Unknown')} | Banner: {banner}")
        open_ports.append((port, banner))
    except:
        pass
    finally:
        s.close()

def nmap_scan(host, port_range):  # <- Note parameters here!
    if port_range.lower() == "common":
        ports = list(COMMON_PORTS.keys())
    else:
        try:
            start_port, end_port = map(int, port_range.split("-"))
            ports = list(range(start_port, end_port + 1))
        except:
            print("Invalid port range format. Use like: 20-100 or 'common'")
            return

    print(f"\n[SIMPLY NMAP] Scanning {host} on ports {port_range}...\n")

    threads = []
    results = []
    for port in ports:
        t = threading.Thread(target=scan_port, args=(host, port, results))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    if results:
        print("\n[SCAN RESULT] Open Ports:")
        for port, banner in sorted(results):
            print(f"  {port} ({COMMON_PORTS.get(port, 'Unknown')}): {banner}")
    else:
        print("[!] No open ports found.")

DEV_KEY = "simplydev2025"


def simply_version():
    return "1.1.4-pvz-2156"
def get_cpu_usage():
    return psutil.cpu_percent(interval=1)

def get_disk_usage():
    disk = psutil.disk_usage('/')
    return f"{disk.percent}% used"

def get_uptime():
    uptime_sec = time.time() - psutil.boot_time()
    hours = int(uptime_sec // 3600)
    minutes = int((uptime_sec % 3600) // 60)
    return f"{hours}h {minutes}m"

def blinking_cursor(stop_event):
    while not stop_event.is_set():
        print('_', end='\r', flush=True)
        time.sleep(0.5)
        print(' ', end='\r', flush=True)
        time.sleep(0.5)

def clearScreen():
    if os.name == 'nt': 
        os.system('cls')

def cmd_ls():
    items = os.listdir(".")
    for item in items:
        if os.path.isdir(item):
            print(colorama.Fore.BLUE + f"[DIR]  {item}" + colorama.Fore.RESET)
        else:
            print(f"       {item}")


def type_print(text, delay=0.015, end="\n"):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print(end=end, flush=True)

def get_ram_info():
    ram_bytes = psutil.virtual_memory().total
    ram_mb = ram_bytes / (1024 ** 2)
    return f"{round(ram_mb)}"

def cmd_ping(host):
    param = '-n' if os.name == 'nt' else '-c'
    try:
        subprocess.run(['ping', param, '4', host])
    except Exception as e:
        print(f"Error pinging host: {e}")

def cmd_whois(domain):
    try:
        result = pywhois.whois(domain)
        print(result)
    except Exception as e:
        print(f"Whois lookup failed: {e}")

def cmd_netstat():
    connections = psutil.net_connections(kind='tcp')
    print("Active TCP Connections:")
    for conn in connections:
        laddr = f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else "-"
        raddr = f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else "-"
        status = conn.status
        print(f"{laddr:<22} --> {raddr:<22} [{status}]")

def cmd_ipconfig():
    try:
        if os.name == 'nt':
            subprocess.run(['ipconfig'], check=True)
        else:
            if shutil.which('ifconfig'):
                subprocess.run(['ifconfig'], check=True)
            elif shutil.which('ip'):
                subprocess.run(['ip', 'a'], check=True)
            else:
                print("Neither 'ifconfig' nor 'ip' is available.")
    except Exception as e:
        print(f"Failed to fetch network config: {e}")

def update_log():
    clearScreen()
    print(colorama.Fore.LIGHTYELLOW_EX + colorama.Style.BRIGHT + "SIMPLY UI VERSION " + simply_version() + colorama.Style.RESET_ALL)
    print("Expanded 'info' command")
    print("Added 'updatelog'command")
    print("Added processes count in 'info'.")
    print("Simplified source code into smaller functions in bigger functions for modularity.")
    print("Added new network commands")
    print("Made launcher into an EXE to run in terminal")
    print("Fixed Hot loading on EXE launcher")
    print("Added some sort of KeyboardInterupt immunity")
    print("Added 'netstat' command")
    print("Added 'google' command to open google on default browser")
    print("Revamped Devmode" + colorama.Fore.RESET)

def print_ascii_art(text):
    try:
        ascii_banner = pyfiglet.figlet_format(text)
        print(colorama.Fore.MAGENTA + ascii_banner + colorama.Fore.RESET)
    except Exception as e:
        print(f"[!] Failed to render ASCII: {e}")

def help_cmd():
    print(colorama.Fore.YELLOW + "\nAvailable Commands:")
    print("  help         - Show this help message")
    print("  clear        - Clear the terminal screen")
    print("  info         - Show system information")
    print("  projects     - Select and run a project based off name")
    print("  update       - Live update code may take a while.")
    print("  clock        - Display local system time")
    print("  updatelogs   - Display update logs for latest release of simplyUI")
    print("  devmode      - Enter developer mode with extra commands")
    print(" 'Ctrl + C'    - Restart current module")
    print(" ping <host>   - Ping a host")
    print("whois <domain> - Get WHOIS info for a domain")
    print(" ipconfig      - Show network configuration")
    print(" echo <text>   - System mimics input")
    print(" ascii <text>  - Creates ASCII art")
    print(" google        - Opens google on default browser")
    print(" netstat       - Show active TCP connections on your machine.")
    print(" news          - Prints news")
    print(" nmap <target> <common> - Run an nmap on a target and find open ports")
    print(" exit          - Exit the terminal\n" + colorama.Fore.RESET)

def projects_cmd():
    type_print("Enter the name of a project to run or type 'back' to return.")
    while True:
        project_name = input("projects@simply:~$ ").strip()
        if project_name == "back":
            break
        elif os.path.isfile(f"projects/{project_name}.py"):
            subprocess.run([sys.executable, f"projects/{project_name}.py"])
        else:
            type_print("Project not found.")
def print_boot_logo():
    ascii_art = pyfiglet.figlet_format("SIMPLY")
    type_print(colorama.Fore.CYAN + ascii_art)
    type_print(colorama.Fore.YELLOW + "     S I M P L Y   T E R M I N A L")
    type_print(colorama.Fore.YELLOW + "       Version " + simply_version() + colorama.Fore.RESET)

def entryUI():
    type_print(colorama.Fore.GREEN + "Welcome to S-I-M-P-L-Y UI, What do you want to be reffered to as? " + colorama.Fore.RESET)
    time.sleep(1)

    while True:
        identify = input (colorama.Style.BRIGHT + colorama.Fore.YELLOW + "Preferred identifier: " + colorama.Fore.RESET).strip()
        if len(identify) == 0:
            type_print(colorama.Fore.RED + "Identifier cannot be empty or just spaces. Try again.")
            time.sleep(1)
        else:
            break
    type_print(colorama.Fore.GREEN + colorama.Style.BRIGHT + "Welcome " + identify.upper() + " to S-I-M-P-L-Y UI.")
    time.sleep(1.5)
    clearScreen()
    return identify


def loadingBar():
    bar_length = 40
    spin_chars = ['|', '/', '-', '\\']
    start_time = time.time()

    print(colorama.Fore.GREEN + colorama.Style.BRIGHT + "Loading..." + colorama.Fore.RESET)
    for i in range(bar_length + 1):
        percent = (i / bar_length) * 100
        bar = "#" * i + "-" * (bar_length - i)
        spin_char = spin_chars[i % len(spin_chars)]

        elapsed = time.time() - start_time
        elapsed_str = f"{elapsed:.1f}s"

        if i % 2 == 0:
            bar_color = colorama.Fore.GREEN
        else:
            bar_color = colorama.Fore.YELLOW

        sys.stdout.write(f"\r{bar_color}[{bar}]{colorama.Fore.RESET} {percent:5.1f}% {spin_char} Elapsed: {elapsed_str}")
        sys.stdout.flush()
        time.sleep(0.1)

    print("\nAll Assets Loaded, Booting System Drive...\n")
    clearScreen()

def menuBooted(identify):
    #getting info from functions
    ram = get_ram_info()
    cpu = get_cpu_usage()
    disk = get_disk_usage()
    uptime = get_uptime()

    # fancy schmancy loading
    type_print(colorama.Fore.GREEN + "SUCESSFULLY LOADED BOOT DRIVE. . . .")
    time.sleep(1)
    type_print(colorama.Fore.WHITE + "TESTING SYSTEM ENVIRONMENT. . . . .")
    time.sleep(3)
    clearScreen()
    print_boot_logo()

    # system stats
    print(colorama.Fore.GREEN + f"RAM: {ram} MB AVAILABLE")
    time.sleep(0.8)
    print(colorama.Fore.GREEN + f"CPU Usage: {cpu}%")
    time.sleep(0.8)
    print(colorama.Fore.GREEN + f"Disk Usage: {disk}")
    time.sleep(0.8)
    print(colorama.Fore.GREEN + f"System Uptime: {uptime}")
    time.sleep(0.8)
    print(colorama.Fore.GREEN + "READY FOR BOOT")
    time.sleep(1)

    while True :
        type_print(colorama.Fore.GREEN + colorama.Style.BRIGHT + "Proceed?")
        time.sleep(1)
        proceed = input("Y/N: ").strip().lower()
        if (proceed == "y"):
            mainMenu(identify)
            break
        elif (proceed == "n"):
            clearScreen()
            type_print(colorama.Fore.RED + colorama.Style.BRIGHT + "TERMINATING PROCESS" + colorama.Fore.RESET)
            sys.exit()
        else:
            type_print(colorama.Fore.RED + colorama.Style.BRIGHT + "INVALID SELECTION, ENTER 'y' or 'n'. ")
            time.sleep(1)


def mainMenu(username):
    tasks = [
        "Initializing kernel modules...",
        "Establishing secure connection...",
        "Fetching system telemetry...",
        "Loading command shell environment...",
        "Checking for critical updates...",
        "Synchronizing system clock...",
        "Verifying hardware integrity...",
        "Mounting user environment...",
        "Boot finalization in progress...",
        "System Ready. Launching Interface..."
    ]

    print(colorama.Fore.CYAN + colorama.Style.BRIGHT + "\n[ SYSTEM TASK QUEUE ]\n" + colorama.Fore.RESET)

    for task in tasks:
        type_print(f"[✓] {task}", delay=0.02)
        time.sleep(0.5)

    type_print(colorama.Fore.GREEN + "\nAll tasks completed successfully." + colorama.Fore.RESET)
    time.sleep(0.3)
    type_print(colorama.Fore.YELLOW + f"\nWelcome, {username.upper()}. Your terminal session has started." + colorama.Fore.RESET)
    time.sleep(0.3)
    type_print(colorama.Fore.WHITE + "\n> Type 'help' to see available commands.\n" + colorama.Fore.RESET)
    while True:
            command = input(colorama.Fore.CYAN + f"{username}@simply:~$ " + colorama.Fore.RESET).strip().lower()

            if command.lower() == "update":
                type_print("Update command received. Hot loading code...")
                return "update"

            elif command.lower() == "help":
                help_cmd()

            elif command.lower() == "clear":
                clearScreen()

            elif command.lower() == "info":
                info_cmd(username)

            elif command.lower().startswith("news"):
                cmd_news()

            elif command.lower() == "exit":
                type_print(colorama.Fore.RED + "\nExiting SIMPLY Terminal..." + colorama.Fore.RESET)
                time.sleep(1)
                sys.exit()

            elif command.lower().startswith("echo "):
                to_echo = command[5:]
                type_print(to_echo)

            elif command.lower() == "projects":
                projects_cmd()

            elif command.lower() == "google":
                webbrowser.open("https://www.google.com")
                type_print("Opening Google in your default browser...")

            elif command.lower() == "updatelogs":
                update_log()

            elif command.lower() == "ipconfig":
                cmd_ipconfig()

            elif command.lower().startswith("ascii"):
                text = command[6:].strip() or "SIMPLY UI"
                print_ascii_art(text)

            elif command.lower().startswith("ping "):
                host = command.split(" ", 1)[1]
                cmd_ping(host)

            elif command.lower().startswith("whois "):
                domain = command.split(" ", 1)[1]
                cmd_whois(domain)

            elif command == "netstat":
                cmd_netstat()

            elif command.lower().startswith("nmap "):
                    parts = command.split()
                    if len(parts) != 3:
                        print("Usage: nmap <target_ip> <port-range>")
                    else:
                        host = parts[1]
                        port_range = parts[2]
                        nmap_scan(host, port_range)

            elif command.lower() == "clock":
                from datetime import datetime
                type_print("Gathering time data...")
                time.sleep(0.8)
                type_print("Syncing system clock...")
                time.sleep(0.8)
                now = datetime.now()
                localtime = now.strftime("%H:%M:%S")
                type_print(colorama.Fore.LIGHTBLUE_EX + colorama.Style.BRIGHT + "Current time (hrs:min:sec): " + localtime + colorama.Fore.RESET + colorama.Style.RESET_ALL)

            elif command.lower() == "devmode":
                dev_key = input("Enter developer key: ").strip()
                if dev_key == DEV_KEY:
                    type_print("Developer mode activated.")
                    dev_mode_menu()
                else:
                    type_print("Invalid key. Access denied.")
            else:
                type_print(colorama.Fore.RED + "Unknown command or invalid permissions. Type 'help' for a list of commands." + colorama.Fore.RESET)

# info cmd under mainmenu func so username is recognized
def info_cmd(username):
    clearScreen()
    count = len(psutil.pids())
    type_print("Gathering system information...", delay=0.02)
    type_print(f"Username: {username}")
    type_print(f"RAM: {get_ram_info()} MB")
    type_print(f"Platform: {sys.platform}")
    type_print(f"Operating System: {platform.system()} {platform.release()}")
    type_print(f"Python Version: {sys.version.split()[0]}")
    type_print(f"Number of running processes: {count}")
    type_print("SimplyUI Version: " + simply_version()) 

# developer mode stuff 
def dev_mode_menu():
    type_print("Welcome to Developer Mode. Type 'back' to return and 'devhelp' for commands.")
    while True:
        cmd = input("dev@simply:~$ ").strip().lower()
        if cmd == "back":
            type_print("Exiting Developer Mode.")
            break
        elif cmd == "tasks":
            type_print("Current active threads: " + str(threading.active_count()))
        elif cmd == "devhelp":
            print(colorama.Fore.YELLOW + "\nAvailable Developer Commands:")
            print("  devhelp    - Show this help message")
            print("  back       - Return to default user terminal screen")
            print("  tasks      - Display local running threads\n" + colorama.Fore.RESET)
        else:
            type_print("Unknown developer command.")
